(()=>{
  'use strict';
  const cfg={supabaseUrl:'https://iresvqwyaqotghjssncg.supabase.co',publishableKey:'sb_publishable_9yUn07uD4XYySt1ynzZu-A_v8HSoSDO'};
  const auth=window.AGVSession.create(cfg),$=id=>document.getElementById(id);
  const school='@escola.pr.gov.br';
  let profile=null;
  const setMsg=(t='',error=false)=>{const e=$('login-message');e.textContent=t;e.classList.toggle('error',error)};
  async function loadProfile(){const user=await auth.getUser();const rows=await auth.request(`/rest/v1/profiles?select=id,full_name,email,role,active,must_change_password&id=eq.${encodeURIComponent(user.id)}&limit=1`);const p=Array.isArray(rows)?rows[0]:null;if(!p?.active)throw new Error('Acesso inativo.');profile=p;if(p.must_change_password){location.replace('atividades/');return {redirected:true,profile:p};}return {redirected:false,profile:p};}
  function renderSigned(){const role=profile?.role||'student';$('login-card').classList.add('hidden');$('signed').classList.remove('hidden');$('user-name').textContent=profile?.full_name||profile?.email||'Usuário';$('user-role').textContent=role==='student'?'Aluno':role==='teacher'?'Professor':role==='admin'?'Administrador':'Super Admin';document.querySelectorAll('[data-role]').forEach(el=>{const allowed=el.dataset.role.split(',').includes(role);el.classList.toggle('hidden',!allowed)});}

  async function renderPlatforms(){const host=$('hub-platform-grid');if(!host)return;try{const r=await fetch('core/catalog/platform-integration-v14.0.json',{cache:'no-store'});if(!r.ok)throw new Error('catalog');const data=await r.json();const items=(data.platforms||[]).filter(x=>x.readyForUnifiedHub).slice(0,10);host.replaceChildren();for(const item of items){const a=document.createElement('a');a.className='platform-mini';a.href=item.route;a.innerHTML=`<span>${item.icon||'🧩'}</span><div><strong>${item.name}</strong><small>${item.category||'Plataforma integrada'}</small></div><b>→</b>`;host.appendChild(a)}}catch(_){host.textContent='O catálogo de plataformas está temporariamente indisponível.'}}
  function renderGuest(){$('signed').classList.add('hidden');$('login-card').classList.remove('hidden');}
  async function restore(){const s=await auth.getSession();if(!s)return renderGuest();try{const result=await loadProfile();if(result?.redirected)return;renderSigned();}catch{await auth.signOut();renderGuest();}}
  $('login-form').addEventListener('submit',async e=>{e.preventDefault();const btn=e.submitter,email=$('email').value.trim().toLowerCase(),password=$('password').value;if(!email.endsWith(school))return setMsg(`Use seu e-mail institucional ${school}.`,true);btn.disabled=true;setMsg('Entrando…');try{try{await auth.signIn(email,password);}catch(first){if(!/^\d{6,12}$/.test(password))throw first;setMsg('Validando primeiro acesso…');const out=await auth.signUpStudent(email,password,location.href);if(!out?.access_token)await auth.signIn(email,password);}const result=await loadProfile();if(result?.redirected)return;renderSigned();setMsg();}catch(err){console.error(err);await auth.signOut();setMsg('Não foi possível entrar. Aluno no primeiro acesso: use o CGM. Equipe: use sua senha individual.',true);}finally{btn.disabled=false;}});
  $('logout').addEventListener('click',async()=>{await auth.signOut();profile=null;renderGuest();});
  auth.onStorage(()=>restore());renderPlatforms();restore();
})();
