# Exercício 05 — Operadores lógicos e validações em Python

## Objetivo

Combinar critérios com `and`, `or` e `not` para construir um controle de acesso a um evento, validando idade e respostas informadas pelo usuário.

## Arquivo

- `main.py`

## Conteúdos trabalhados

- operadores lógicos `and`, `or` e `not`;
- valores booleanos;
- validação de intervalo de idade;
- validação de respostas de texto;
- condições combinadas;
- `if`, `elif` e `else`;
- conversão com `int()`;
- f-strings;
- leitura de erros no terminal.

## Regras do programa

1. Idades menores que 0 ou maiores que 120 representam dados inválidos.
2. Respostas diferentes de `s`, `sim`, `n`, `nao` ou `não` representam dados inválidos.
3. Participantes com 18 anos ou mais precisam possuir ingresso válido.
4. Participantes de 14 a 17 anos precisam possuir ingresso válido **e** autorização do responsável.
5. Participantes abaixo de 14 anos não têm a entrada liberada nesta atividade.
6. Quando o ingresso não estiver confirmado, o terminal informa o motivo.

## Como executar

No terminal do VS Code, dentro da pasta `exercicio-05`:

```bash
py main.py
```

ou:

```bash
python main.py
```

## Testes obrigatórios

### Teste 1 — Adulto com ingresso

```text
Nome: Ana
Idade: 20
Ingresso: s
Autorização: n
Resultado: Entrada liberada
```

### Teste 2 — Adolescente autorizado

```text
Nome: Bruno
Idade: 16
Ingresso: s
Autorização: s
Resultado: Entrada liberada com autorização
```

### Teste 3 — Adolescente sem autorização

```text
Nome: Carla
Idade: 16
Ingresso: s
Autorização: n
Resultado: Entrada não permitida
```

### Teste 4 — Dados inválidos

```text
Nome: Davi
Idade: 150
Ingresso: s
Autorização: s
Resultado: Dados inválidos
```

## Erros para observar

1. Troque um `and` por `or` e observe como a regra muda.
2. Remova um `not` da validação e compare o resultado.
3. Digite texto no campo da idade e leia o `ValueError`.
4. Remova os dois-pontos de uma condição e leia o `SyntaxError`.
5. Retire a indentação de uma linha e leia o `IndentationError`.
6. Corrija o código e execute novamente.
