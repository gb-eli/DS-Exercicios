# Exercício 08 — Repetição com `while` em Python

## Objetivo

Criar um controle de acesso que repete a solicitação de senha enquanto houver tentativas disponíveis e o acesso ainda não tiver sido liberado.

## Arquivo

- `main.py`

## Conteúdos trabalhados

- repetição com `while`;
- condição de continuidade;
- contador de tentativas;
- valor booleano;
- operador `not`;
- operador `and`;
- atualização com `+=`;
- retomada de `if` e `else`;
- mensagens com f-strings;
- encerramento do laço por sucesso ou por limite.

## Conceito principal

O `while` repete um bloco enquanto sua condição for verdadeira:

```python
while tentativas < limite_tentativas and not acesso_liberado:
    # instruções repetidas
```

Neste exercício, a repetição continua somente quando as duas condições são verdadeiras:

1. ainda existem tentativas disponíveis;
2. o acesso ainda não foi liberado.

## Regras do programa

1. A senha didática correta é `python123`.
2. O usuário possui no máximo três tentativas.
3. Uma senha correta altera o valor booleano de acesso.
4. Uma senha incorreta aumenta o contador.
5. O programa informa quantas tentativas ainda restam.
6. Ao final, o terminal informa se o acesso foi liberado ou bloqueado.

> Esta é uma simulação didática. Senhas reais não devem ficar escritas diretamente no código.

## Como executar

No terminal do VS Code, dentro da pasta `exercicio-08`:

```bash
py main.py
```

ou:

```bash
python main.py
```

## Teste principal

Digite duas senhas incorretas e depois a senha correta:

```text
abc
123
python123
```

Resultado esperado:

```text
Senha incorreta. Restam 2 tentativa(s).
Senha incorreta. Restam 1 tentativa(s).
Acesso liberado!
```

## Testes adicionais

1. Acerte na primeira tentativa.
2. Erre as três tentativas e confira o bloqueio.
3. Acerte na terceira tentativa.
4. Troque o limite para cinco e observe a condição do `while`.
5. Remova `not` e analise por que a repetição deixa de funcionar corretamente.
6. Remova `tentativas += 1` e observe o risco de laço infinito.
7. Remova os dois-pontos do `while` e leia o `SyntaxError`.
8. Retire a indentação do corpo do laço e leia o `IndentationError`.
