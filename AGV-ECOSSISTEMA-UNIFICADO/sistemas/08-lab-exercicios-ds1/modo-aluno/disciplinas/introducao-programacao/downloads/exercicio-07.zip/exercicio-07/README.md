# Exercício 07 - Contadores e acumuladores em Python

## Objetivo

Registrar pedidos de uma lanchonete, acumular o valor vendido e contar quantos pedidos foram pequenos, médios ou grandes.

## Arquivo

- `main.py`

## Conteúdos trabalhados

- repetição com `for`;
- função `range()`;
- contador;
- acumulador;
- operador de atribuição `+=`;
- cálculo de ticket médio;
- retomada de `if`, `elif` e `else`;
- conversões com `int()` e `float()`;
- entrada decimal com ponto ou vírgula;
- f-strings e formatação monetária.

## Conceitos principais

Um **contador** registra quantas vezes uma situação ocorreu:

```python
pedidos_pequenos = 0
pedidos_pequenos += 1
```

Um **acumulador** guarda a soma dos valores ao longo das repetições:

```python
total_vendas = 0.0
total_vendas += valor
```

## Regras do programa

1. O usuário informa a quantidade de pedidos.
2. A quantidade deve ser maior que zero.
3. O `for` solicita o valor de cada pedido.
4. O acumulador soma todos os valores vendidos.
5. Pedido abaixo de R$ 20 é classificado como pequeno.
6. Pedido de R$ 20 até menos de R$ 50 é classificado como médio.
7. Pedido de R$ 50 ou mais é classificado como grande.
8. Ao final, o programa mostra total vendido, ticket médio e os três contadores.

## Como executar

No terminal do VS Code, dentro da pasta `exercicio-07`:

```bash
py main.py
```

ou:

```bash
python main.py
```

## Teste principal

Informe quatro pedidos:

```text
12
25
60
43
```

Resultado esperado:

```text
Total vendido: R$ 140.00
Ticket médio: R$ 35.00
Pedidos pequenos: 1
Pedidos médios: 2
Pedidos grandes: 1
```

## Testes adicionais

1. Informe apenas um pedido.
2. Use exatamente os limites `20` e `50`.
3. Digite um valor com vírgula, como `18,50`.
4. Informe quantidade zero e confira a validação.
5. Remova um `+= 1` e observe o contador incorreto.
6. Troque `total_vendas += valor` por uma atribuição simples e compare o total.
7. Remova a indentação do corpo do `for` e leia o `IndentationError`.
8. Digite texto em uma entrada numérica e leia o `ValueError`.
