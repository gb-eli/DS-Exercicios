# Exercício 06 — Repetição com `for` em Python

## Objetivo

Criar uma tabuada configurável para compreender como o laço `for` repete um bloco de instruções e como a função `range()` produz uma sequência numérica.

## Arquivo

- `main.py`

## Conteúdos trabalhados

- repetição com `for`;
- variável de controle;
- função `range()`;
- valor inicial e limite final;
- limite final exclusivo do `range()`;
- multiplicação dentro do laço;
- indentação;
- retomada de `if` e `else` para validar o intervalo;
- conversão com `int()`;
- saída formatada com f-strings.

## Regras do programa

1. O usuário informa o número da tabuada.
2. O usuário informa o multiplicador inicial.
3. O usuário informa o multiplicador final.
4. Quando o início for maior que o fim, o programa mostra uma mensagem de intervalo inválido.
5. Nos demais casos, o `for` percorre todos os multiplicadores do início até o fim.
6. Como o limite final do `range()` não é incluído, o código usa `fim + 1`.

## Como executar

No terminal do VS Code, dentro da pasta `exercicio-06`:

```bash
py main.py
```

ou:

```bash
python main.py
```

## Teste principal

```text
Número da tabuada: 7
Multiplicador inicial: 1
Multiplicador final: 5
```

Resultado esperado:

```text
--- TABUADA DO 7 ---
7 x 1 = 7
7 x 2 = 14
7 x 3 = 21
7 x 4 = 28
7 x 5 = 35
```

## Testes adicionais

1. Use início e fim iguais, como `4` e `4`.
2. Use um intervalo que começa em `0`.
3. Informe início maior que o fim e confira a validação.
4. Remova o `+ 1` e observe que o último multiplicador deixa de aparecer.
5. Remova a indentação do corpo do `for` e leia o `IndentationError`.
6. Remova os dois-pontos do `for` e leia o `SyntaxError`.
7. Digite texto em uma entrada numérica e leia o `ValueError`.
