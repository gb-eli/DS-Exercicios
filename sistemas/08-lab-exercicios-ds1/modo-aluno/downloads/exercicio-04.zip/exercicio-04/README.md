# Exercício 04 — Condições com `if`, `elif` e `else`

## Objetivo

Aprender a criar três caminhos de decisão em Python, classificando a situação escolar de um aluno a partir da média de duas notas.

## Arquivos

- `main.py`

## Conteúdos trabalhados

- entrada de texto com `input()`;
- conversão com `float()`;
- cálculo de média;
- estrutura `if`;
- uma condição intermediária com `elif`;
- caminho final com `else`;
- operadores `>=`;
- dois-pontos e indentação;
- f-strings e formatação decimal.

## Como executar

No terminal do VS Code, dentro da pasta do exercício:

```bash
py main.py
```

ou:

```bash
python main.py
```

## Regras da classificação

```text
Média igual ou superior a 7,0       → Aprovado
Média igual ou superior a 5,0       → Recuperação
Média inferior a 5,0                → Reprovado
```

A ordem das condições é importante. Quando a primeira condição for falsa, o Python verifica o `elif`. O `else` será usado somente quando nenhuma condição anterior for verdadeira.

## Testes obrigatórios

### Teste 1 — Aprovado

```text
Nome: Ana
Nota 1: 8
Nota 2: 6
Resultado: Média 7.0 — Aprovado
```

### Teste 2 — Recuperação

```text
Nome: Bruno
Nota 1: 6
Nota 2: 5
Resultado: Média 5.5 — Recuperação
```

### Teste 3 — Reprovado

```text
Nome: Carla
Nota 1: 4
Nota 2: 5
Resultado: Média 4.5 — Reprovado
```

## Erros para observar

1. Remova os dois-pontos depois de `if` ou `elif` e leia o `SyntaxError`.
2. Retire a indentação de uma linha e leia o `IndentationError`.
3. Digite uma palavra no lugar de uma nota e leia o `ValueError`.
4. Troque a ordem das condições e observe como a classificação pode ficar incorreta.
5. Corrija o código e execute novamente.
